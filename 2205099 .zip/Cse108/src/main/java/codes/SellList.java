package codes;

import java.io.Serializable;

public class SellList extends players implements Serializable {

}
