package codes;
import javafx.fxml.FXMLLoader;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.CompletableFuture;

public class LoginScreen {

    Main main;
    String clubFromServer;
    List<player> ListfromServer;

    @FXML
    private TextField ClubName;

    @FXML
    private TextField AccessCode;

    public void setClubFromServer(String clubFromServer) {
        this.clubFromServer = clubFromServer;
    }
    public SellList sellList=new SellList();
    synchronized public void SellState(SellList s)
    {
        sellList=s;
        System.out.println("SellList: "+sellList.list.size());
        return;
    }
    @FXML
    private Button ShowPlayers;

    @FXML
    private TextArea details7;

    @FXML
    public void Showplayers() throws IOException {
        details7.appendText("Players in the club are: ");
        for (player p : ListfromServer) {
            details7.appendText(p.toString2() + "\n");
        }
    }

    public void setListfromServer(List<player> ListfromServer) {
        this.ListfromServer = ListfromServer;
    }
    @FXML
    private VBox vbox;
    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    @FXML
    private Button SellBut;

    @FXML
    private TextField SellText;

    public void onBackClick() throws IOException {
        // main.showHomePage();
    }

    private void ShowError(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void ShowConfirmation(String message, Runnable onConfirm) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText(null);
            alert.setContentText(message);

            ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

            alert.getButtonTypes().setAll(okButton, cancelButton);

            alert.showAndWait().ifPresent(response -> {
                if (response == okButton) {
                    onConfirm.run();
                }
            });
        });
    }


    public void SellButton() {
        String playerToSell = this.SellText.getText();
        if (playerToSell.equals("")) {
            ShowError("Please enter a player name to sell");
        } else {
            ShowConfirmation("Are you sure you want to sell " + playerToSell + "?", () -> {
                try {
                    main.getSocketWrapper().write("Sell Player,"+playerToSell+","+clubFromServer);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    private void search(String playerName) throws IOException {
        System.out.println("Searching for: " + playerName+" in club "+clubFromServer);
        main.getSocketWrapper().write("Sell Player,"+playerName+","+clubFromServer);
    }
    @NotNull
    private CompletableFuture<int[]> ShowPlayerDetailsInput() {
        CompletableFuture<int[]> resultFuture = new CompletableFuture<>();

        Platform.runLater(() -> {
            Alert salaryAlert = new Alert(Alert.AlertType.CONFIRMATION);
            salaryAlert.setTitle("Player Salary");
            salaryAlert.setHeaderText(null);
            salaryAlert.setContentText("What will be the player's salary?");

            TextField salaryField = new TextField();
            salaryField.setPromptText("Enter salary");
            salaryAlert.getDialogPane().setContent(salaryField);

            ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            salaryAlert.getButtonTypes().setAll(okButton, cancelButton);

            salaryAlert.showAndWait().ifPresent(response -> {
                if (response == okButton) {
                    String salaryInput = salaryField.getText();
                    try {
                        int salary = Integer.parseInt(salaryInput);
                        askForJerseyNumber(salary, resultFuture);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid salary input.");
                        resultFuture.completeExceptionally(e);
                    }
                } else {
                    resultFuture.completeExceptionally(new RuntimeException("User cancelled the operation."));
                }
            });
        });

        return resultFuture;
    }

    private void askForJerseyNumber(int salary, CompletableFuture<int[]> resultFuture) {
        Platform.runLater(() -> {
            Alert jerseyAlert = new Alert(Alert.AlertType.CONFIRMATION);
            jerseyAlert.setTitle("Player Jersey Number");
            jerseyAlert.setHeaderText(null);
            jerseyAlert.setContentText("What will be the player's jersey number?");

            TextField jerseyField = new TextField();
            jerseyField.setPromptText("Enter jersey number");
            jerseyAlert.getDialogPane().setContent(jerseyField);

            ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            jerseyAlert.getButtonTypes().setAll(okButton, cancelButton);

            jerseyAlert.showAndWait().ifPresent(response -> {
                if (response == okButton) {
                    String jerseyInput = jerseyField.getText();
                    try {
                        int jerseyNumber = Integer.parseInt(jerseyInput);
                        resultFuture.complete(new int[]{salary, jerseyNumber});
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid jersey number input.");
                        resultFuture.completeExceptionally(e);
                    }
                } else {
                    resultFuture.completeExceptionally(new RuntimeException("User cancelled the operation."));
                }
            });
        });
    }
    private void searchtobuy(String playerName) throws IOException {
        System.out.println("Searching for: " + playerName);
        boolean f=true;
        main.getSocketWrapper().write("Buy Player,"+playerName+","+clubFromServer);
    }
    @FXML
    private TextArea details10;
    @FXML
    private TextField BuyPlayer;
    @FXML
    public void SearchBP()
    {
        String playerName = BuyPlayer.getText().trim();
        if (playerName.equals("")) {
            ShowError("Please enter a player name to buy");
        } else {
            ShowConfirmation("Are You sure to buy this player?", () -> {
                try {
                    searchtobuy(playerName);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    public void onLoginClick() throws IOException {
        String clubName = this.ClubName.getText();
        String accessCode = this.AccessCode.getText();

        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setClubName(clubName);
        loginDTO.setAccessCode(accessCode);

        main.getSocketWrapper().write("Check Login");
        main.getSocketWrapper().write(loginDTO);
        System.out.println("LoginDTO Sent");
    }

    public void onRegisterClick() throws IOException {
        // main.goToRegisterPage();
    }
    @FXML
    private Button Free;
    @FXML
    public void updateSellList() {
        try {

            main.getSocketWrapper().write("SellList");
        } catch (IOException e) {
            ShowError("Error requesting SellList from server");
        }
    }
    @FXML
    private TextArea details11;

    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (details11 == null) {
            System.out.println("details11 is not initialized yet!");
            
        }
    }
    public void FreeAgent(SellList s) {
        Platform.runLater(() -> {
            if (details11 != null) {
                details11.clear();  // আগের টেক্সট পরিষ্কার করা
                System.out.println("FreeAgent " + s.list.size());
                for (player p : s.list) {
                    details11.appendText(p.toString2() + "\n");  // নতুন প্লেয়ারদের অ্যাড করা
                }
            } else {
                System.out.println("details11 is null");
            }
        });
    }



    }




