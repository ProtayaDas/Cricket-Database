package codes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class Main extends Application {
    Stage stage;
    SocketWrapper socketWrapper;
    Main main = this;
    LoginScreen loginController;
    @Override
    public void start(Stage stage) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Home.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 620, 440);
        HomePageController controller = fxmlLoader.getController();
        controller.setMain(this);

        stage.setTitle("HomePage hello!");
        stage.setScene(scene);
        this.stage = stage;
        stage.show();
    }

    public void goToLoginPage() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("LoginScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 620, 440);

        loginController = fxmlLoader.getController();
        loginController.setMain(this);  // Set main for LoginScreen
        connectToServer();
        stage.setTitle("Login Page");
        stage.setScene(scene);
        stage.show();
    }

    public SocketWrapper getSocketWrapper() {
        return socketWrapper;
    }

    public void connectToServer() throws IOException {
        int serverPort = 4000;
        socketWrapper = new SocketWrapper("localhost", serverPort);

        // Pass LoginScreen object to ReadThreadClient
        new ReadThreadClient(this, this.getSocketWrapper(),loginController ); // Modify null based on usage
    }

    public void set(LoginScreen loginController, String username, List<player> list) throws IOException {
        loginController.setListfromServer(list);
        loginController.setClubFromServer(username);

        // Send login data to the server from LoginScreen

        main.getSocketWrapper().write("Login," + username);
    }

    public void showDashboard(String Clubname, List<player> list) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("buySell.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1000, 800);
        stage.setTitle("Login Page " + Clubname);

        LoginScreen loginController = fxmlLoader.getController();
        loginController.setMain(this);
        set(loginController, Clubname, list);  // Send data from LoginScreen to Server
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
