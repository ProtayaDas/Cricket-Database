package codes;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HomePageController {
    public Button SearchByName;
    private Scene scene;
    private Stage stage;
    private Parent root;
    private Main main;
    players dataB= new players();
    public void setMain(Main main)
    {
        this.main=main;
    }
    public HomePageController()
    {
        try {
            dataB.load();
        }
        catch (Exception e)
        {
            System.out.println("Error Loading Message");
        }
    }
    void ShowError(String message)
    {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    void ShowInfo(String message)
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Info");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    void ShowWarning(String message)
    {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public void callEdit(ActionEvent actionEvent) throws Exception {
        System.exit(0);
    }
    @FXML
    private Button searchByName;
    @FXML
    private Button searchByClub;
    @FXML
    private TextField searchAge;
    @FXML
    private TextField searchCountry;
    @FXML
    private TextField searchPosition,searchbyMinSal,searchbyMaxSal,ClubName;
    @FXML
    private TextArea details1,details2,details3,details4,details5,details6;
    @FXML
    private TextField sNameText,SClubText,SCountryText;

    @FXML
    public  void searchName(ActionEvent actionEvent) throws Exception
    {
        String name=sNameText.getText().trim();
        name=name.toLowerCase();
        if (name.isEmpty())
        {
            ShowError("Please Enter Name");
            return;
        }
        List<player> P = dataB.searchName(name);

        if(P.isEmpty())
        {
            ShowError("No Player Found");
            return;
        }
        else{
            for(player p:P)
            {
                details1.setText(p.toString2());
            }
        }
    }
    @FXML
    public  void SearchClubCountry(ActionEvent actionEvent) throws Exception
    {
        String club=SClubText.getText().trim();
        String country=SCountryText.getText().trim();
        if (club.isEmpty())
        {
            ShowError("Please Enter Club Name");
            return;
        }
        if(country.isEmpty())
        {
            ShowError("Please Enter Country Name");
            return;
        }
        List<player> P = dataB.searchClubCountry(country,club);

        if(P.isEmpty())
        {
            ShowError("No Player Found");
            return;
        }
        else{
            for(player p:P)
            {
                details2.appendText(p.toString2());
                details2.appendText("");
            }
        }
    }
    @FXML
    void searchBatsman()
    {
        details3.clear();
        List<player> Player = dataB.searchPosition("Batsman");
        if (Player.isEmpty())
        {
            details3.setText("No such player with this position.");
        }
        else
        {
            for(player p :Player)
            {
                details3.appendText(p.toString2()+"\n");
            }
        }
    }
    @FXML
    void searchBowler()
    {
        details3.clear();
        List<player> Player = dataB.searchPosition("Bowler");
        if (Player.isEmpty())
        {
            details3.setText("No such player with this position.");
        }
        else
        {
            for(player p :Player)
            {
                details3.appendText(p.toString2()+"\n");
            }
        }
    }
    @FXML
    void searchAllrounder()
    {
        details3.clear();
        List<player> Player = dataB.searchPosition("Allrounder");
        if (Player.isEmpty())
        {
            details3.setText("No such player with this position.");
        }
        else
        {
            for(player p :Player)
            {
                details3.appendText(p.toString2()+"\n");
            }
        }
    }
    @FXML
    private Button MaxSal,MinSal,MaxAge,TotSal;
    @FXML
    void sbyMinMaxSal()
    {
        details4.clear();
        Integer  min,max;
        String mi=searchbyMinSal.getText().trim();
        String ma=searchbyMinSal.getText().trim();
        if(mi.isEmpty())min=0;
        else min=Integer.parseInt(mi);
        if(ma.isEmpty())max=2000000000;
        else max=Integer.parseInt(ma);
        List<player> Player = dataB.searchSalary(min,max);
        if (Player.isEmpty())
        {
            details4.setText("No such player with this salary range.");
        }
        else
        {
            for(player p :Player)
            {
                details4.appendText(p.toString2()+"\n");
            }
        }
    }
    @FXML
    public void CWPC()
    {
        details5.clear();
        HashMap<String,Integer> Player = dataB.searchCountry();
        Player.forEach((key, value) -> details5.appendText(key + ": " + value + "\n"));
    }
    @FXML
    public void FMaxSal(ActionEvent actionEvent)
    {
        String club=ClubName.getText().trim();
        details6.clear();
        if (club.isEmpty())
        {
            ShowError("Please Enter Club Name");
            return;
        }
        List<player> Player = dataB.searchMaximumSalaryClub(club);
        if (Player.isEmpty())
        {
            ShowError("No such player in this     club.");
        }
        else
        {
            for(player p :Player)
            {
                details6.appendText(p.toString2()+"\n");
            }
        }
    }
    @FXML
    public void FMaxHei(ActionEvent actionEvent)
    {
        String club=ClubName.getText().trim();
        details6.clear();
        if (club.isEmpty())
        {
            ShowError("Please Enter Club Name");
            return;
        }
        List<player> Player = dataB.searchMaximumHeightClub(club);
        if (Player.isEmpty())
        {
            ShowError("No such player in this  club.");
        }
        else
        {
            for(player p :Player)
            {
                details6.appendText(p.toString2()+"\n");
            }
        }
    }

    @FXML
    private TextField name,country,position,age,club,height,jerseyNumber,weeklySalary;
    @FXML
    public void addPlayer(ActionEvent actionEvent) throws Exception {
        String name1=name.getText().trim();
        String country1=country.getText().trim();

        int age1=Integer.parseInt(age.getText().trim());

        double height1=Double.parseDouble(height.getText().trim());
        String club1=club.getText().trim();
        String position1=position.getText().trim();
        int JerseyNumber1=Integer.parseInt(jerseyNumber.getText().trim());
        int weeklySalary1=Integer.parseInt(weeklySalary.getText().trim());
        if (name1.isEmpty()) {
            ShowError("Please Enter Name");
            return;
        }
        if (country1.isEmpty()) {
            ShowError("Please Enter Country");
            return;
        }
        if (position1.isEmpty()) {
            ShowError("Please Enter Position");
            return;
        }
        if (age1==0) {
            ShowError("Please Enter Age");
            return;
        }
        if (club1.isEmpty()) {
            ShowError("Please Enter Club");
            return;
        }
        if (height1==0) {
            ShowError("Please Enter Height");
            return;
        }
        if (JerseyNumber1==0) {
            JerseyNumber1=-1;
        }
        System.out.println(name1+" "+country1+" "+age1+" "+height1+" "+club1+" "+position1+" "+JerseyNumber1+" "+weeklySalary1);
        player p=new player(name1,country1,age1,height1,club1,position1,JerseyNumber1,weeklySalary1);
        dataB.add_to_file(p);
        dataB.addInList(p);
        ShowInfo("Player Added Successfully");
    }
    @FXML
    public void FMaxAge() {
        String club = ClubName.getText().trim();
        details6.clear();
        if (club.isEmpty()) {
            ShowError("Please Enter Club Name");
            return;
        }
        List<player> Player = dataB.searchMaximumAgeClub(club);
        if (Player.isEmpty()) {
            ShowError("No such player in this club.");
        }

        else {
            for (player p : Player) {
                details6.appendText(p.toString2() + "\n");
            }
        }
    }
    @FXML
    public void Exit()
    {
        Platform.exit();
    }
    @FXML
    public void FTotSal(ActionEvent actionEvent)
    {
        String club=ClubName.getText().trim();
        details6.clear();
        if (club.isEmpty())
        {
            ShowError("Please Enter Club Name");
            return;
        }
        Integer totsal= dataB.searchSalaryClub(club);
        if(totsal==-1){
            details6.setText("No such player in this club.");
        }
        else{
            details6.setText(totsal.toString());
        }
    }
    public void logIn() throws Exception {
        main.goToLoginPage();
    }
    public void BuySearch()throws Exception {

    }


}
