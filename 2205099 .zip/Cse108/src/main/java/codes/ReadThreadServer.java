package codes;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final SocketWrapper socketWrapper;
    public static players playerList;
    public List<player> playersInClub = new ArrayList<>();
    private static boolean refreshVar = false;

    private static ArrayList<SocketWrapper> clientSocketList = new ArrayList<>();

    private HashMap<String, String> loginData;
    private static final String INPUT_FILE_NAME = "E:\\Cse108\\src\\main\\java\\codes\\players.txt";
    private static final String INPUT_FILE_LOGIN = "E:\\Cse108\\src\\main\\java\\codes\\loginData.txt";
    private static final String SELL_DATA_FILE = "E:\\Cse108\\src\\main\\java\\codes\\sellData.txt";

    public static SellList sellStatePlayers = new SellList();
    private final LoginScreen log=new LoginScreen();
    private players addPlayerToDatabase() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_NAME));
        players tempList = new players();

        while (true) {
            String line = "";
            try {
                line = br.readLine();
            } catch (EOFException e) {
                System.out.println("End Of File Exception");
            }

            if (line == null)
                break;

            String[] tokens = line.split(",");

            String name = tokens[0];
            String country = tokens[1];
            int age = Integer.parseInt(tokens[2]);
            double height = Double.parseDouble(tokens[3]);
            String club = tokens[4];
            String position = tokens[5];

            int number;
            if (!tokens[6].isEmpty()) {
                number = Integer.parseInt(tokens[6]);
            } else {
                number = -1;
            }
            int salary = Integer.parseInt(tokens[7]);

            tempList.addInList(new player(name, country, age, height, club, position, number, salary));
        }

        br.close();
        return tempList;
    }

    private void UpdateDatabase() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(INPUT_FILE_NAME));

            for (player x : playerList.list) {
                String text = x.getName() + "," + x.getCountry() + "," + x.getAge() + ","
                        + x.getHeight() + ","
                        + x.getClub() + "," + x.getPosition() + "," + x.getJerseyNumber() + ","
                        + x.getSalary() + '\n';
                bw.write(text);
            }

            bw.close();
            System.out.println("Database Successfully Updated");

        } catch (IOException e) {
            System.out.println("IO Exception");
        }
    }

    public SellList addSellData() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(SELL_DATA_FILE));
        SellList tempList = new SellList();

        while (true) {
            String line = "";
            try {
                line = br.readLine();
            } catch (EOFException e) {
                System.out.println("End Of File Exception");
                break;
            }

            if (line == null) {
                break;
            }

            String[] tokens = line.split(",");
            String name = tokens[0];
            String country = tokens.length > 1 ? tokens[1] : "";
            int age = tokens.length > 2 ? Integer.parseInt(tokens[2]) : 0;
            double height = tokens.length > 3 ? Double.parseDouble(tokens[3]) : 0.0;
            String club = tokens.length > 4 ? tokens[4] : "";
            String position = tokens.length > 5 ? tokens[5] : "";
            int number = tokens.length > 6 && !tokens[6].isEmpty() ? Integer.parseInt(tokens[6]) : -1;
            int salary = tokens.length > 7 ? Integer.parseInt(tokens[7]) : 0;
            String prevClub = tokens.length > 8 ? tokens[8] : "";

            tempList.addInList(new player(name, country, age, height, club, position, number, salary));
        }

        br.close();
        return tempList;
    }

    private void ShowError(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void writeSellData() throws Exception {
        BufferedWriter bw = new BufferedWriter(new FileWriter(SELL_DATA_FILE));

        for (player x : playerList.list) {
            String text = x.getName() + "," + x.getCountry() + "," + x.getAge() + ","
                    + x.getHeight() + ","
                    + x.getClub() + "," + x.getPosition() + "," + x.getJerseyNumber() + ","
                    + x.getSalary() + '\n';
            bw.write(text);
        }

        bw.close();
        System.out.println("Database Successfully Updated");
    }

    private HashMap<String, String> addLoginData() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE_LOGIN));
        HashMap<String, String> ld = new HashMap<>();

        while (true) {
            String line = "";
            try {
                line = br.readLine();
            } catch (EOFException e) {
                System.out.println("End Of File Exception");
            }

            if (line == null)
                break;

            String[] tokens = line.split(",");

            String clubName = tokens[0];
            String accessCode = tokens[1];

            ld.put(clubName, accessCode);
        }
        return ld;
    }

    public ReadThreadServer(SocketWrapper socketWrapper) throws Exception {
        this.loginData = addLoginData();
        clientSocketList.add(socketWrapper);
        System.out.println(clientSocketList.size());
        sellStatePlayers = addSellData();
        this.socketWrapper = socketWrapper;
        this.thr = new Thread(this);
        thr.start();
    }

    private synchronized void Refresh() throws IOException {
        int i = 0;
        for (SocketWrapper x : clientSocketList) {
            x.write("Refresh");
            System.out.println("Wrote Refresh on Socket " + i);
            i++;
        }
    }



    public synchronized void run() {
        try {
            while (true) {
                Object o = socketWrapper.read();
                if (o != null) {
                    if (o instanceof String) {
                        String s = (String) o;
                        String[] tokens = s.split(",");

                        String PlayerName = "";
                        String prevClubName = "";
                        if (tokens.length > 1) {
                            s = tokens[0];
                            PlayerName = tokens[1];
                        }
                        if (tokens.length > 2) {
                            s = tokens[0];
                            PlayerName = tokens[1];
                            prevClubName = tokens[2];
                        }
                        System.out.println("Player Name: " + PlayerName+ " " + tokens[0]);
                        if (s.equals("Fetch Database")) {
                            try {
                                playerList = addPlayerToDatabase();
                                socketWrapper.write(playerList);
                                System.out.println("Sent Database To The Client");
                            } catch (Exception e) {
                                System.out.println("Error While Sending Requested Database");
                            }
                        }
                        else if(s.equals("SellList")) {
                            try {

                                socketWrapper.write(sellStatePlayers);
                                System.out.println("Sent Selling List To The Client");
                            } catch (Exception e) {
                                System.out.println("Error While Sending Selling");
                            }
                        }
                        else if (s.equals("Check Login")) {
                            try {
                                LoginDTO ldto = (LoginDTO) socketWrapper.read();
                                String accessCode = loginData.get(ldto.getClubName());
                                ldto.setStatus(ldto.getAccessCode().equals(accessCode));
                                socketWrapper.write(ldto);
                                System.out.println("Sent Login Data To The Client");
                            } catch (Exception e) {
                                System.out.println("Error While Adding Login Data");
                            }
                        }
                        else if (tokens.length > 1 && tokens[0].equals("Sell Player")) {
                            try {
                                playerList = addPlayerToDatabase();
                                List<player> P = playerList.searchName(PlayerName);
                                if (P.size() == 0 || !(P.get(0).getClub().equals(prevClubName))) {
                                    if (P.size() > 0)
                                        System.out.println(P.get(0).getClub() + " zz " + tokens.length);
                                    else
                                        System.out.println("No Player");
                                    socketWrapper.write("Error,Selling");

                                } else {
                                    System.out.println("Player Successfully Put in Selling List");
                                    for (player x : P) {
                                        System.out.println(x.getClub());
                                        playerList.list.remove(x);
                                        System.out.println(x.getClub() + " 2");
                                        x.setClub("None");
                                        x.setSalary(0);
                                        sellStatePlayers.addInList(x);
                                        System.out.println(x.getClub() + " 3");

                                        Iterator<player> it = playerList.list.iterator();
                                        playerList.list.add(x);
                                        System.out.println(x.getClub() + " 4");
                                    }

                                    writeSellData();
                                    UpdateDatabase();
                                    System.out.println("6");
                                    socketWrapper.write("Success,Selling");
                                    System.out.println("Player Successfully Put in Selling List");
                                    Refresh();
                                }
                            } catch (Exception e) {
                                System.out.println("Error While Selling Player" + e);
                            }
                        }


                        else if (tokens.length > 1 && tokens[0].equals("Buy Player")) {
                            try {
                                playerList = addPlayerToDatabase();
                                List<player> P = playerList.searchName(PlayerName);
                                if (P.isEmpty() || !(P.get(0).getClub().equals("None"))) {
                                    socketWrapper.write("Error,Buying");
                                } else {
                                    for (player x : P) {
                                        sellStatePlayers.list.remove(x);
                                        playerList.list.remove(x);
                                        x.setClub(tokens[2]);

                                        playerList.list.add(x);
                                        writeSellData();
                                        UpdateDatabase();
                                        log.SellState(sellStatePlayers);
                                        //log.FreeAgent();
                                    }
                                    socketWrapper.write("Success,Buying");

                                    System.out.println("Player Successfully Bought");
                                    Refresh();
                                }
                            } catch (Exception e) {
                                System.out.println("Error While Selling Player " + e);
                            }
                        } else if (tokens[0].equals("login")) {
                            try {
                                players templist = addPlayerToDatabase();
                                for (player x : templist.list) {
                                    if (x.getClub().equals(tokens[1])) {
                                        playersInClub.add(x);
                                    }
                                }
                                socketWrapper.write(playersInClub);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Client Closed Connection");
            clientSocketList.remove(socketWrapper);
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Error While Closing Connection");
            }
        }
    }
}