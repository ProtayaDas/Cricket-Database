package codes;
import javafx.fxml.FXMLLoader;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

import java.io.IOException;
import java.util.List;

public class ReadThreadClient implements Runnable {
    private final Thread thr;
    private final SocketWrapper socketWrapper;
    private Main main;
    private players playerList;
    private final LoginScreen log; // Store reference to LoginScreen

    // Constructor accepting LoginScreen
    public ReadThreadClient(Main main, SocketWrapper socketWrapper, LoginScreen log) {
        this.main = main;
        this.socketWrapper = socketWrapper;
        this.log = log;
        System.out.println("ReadThreadClient Created");
        if(log==null)
        {
            System.out.println("Login Screen is null");
        }
        this.thr = new Thread(this);
        thr.start();
    }

    private void ShowConfirmation(String message, Runnable onConfirm) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText(null);
            alert.setContentText(message);

            ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

            alert.getButtonTypes().setAll(okButton, cancelButton);

            alert.showAndWait().ifPresent(response -> {
                if (response == okButton) {
                    onConfirm.run();
                }
            });
        });
    }

    private void ShowError(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private void ShowOk(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    public synchronized void run() {
        while (true) {
            try {
                Object o = socketWrapper.read();

                if (o instanceof SellList) {
                    SellList p = (SellList) o;
                    Platform.runLater(() -> {
                        log.FreeAgent(p);
                    });
                    System.out.println("Setting Up Sell Database...");
                } else if (o instanceof players) {
                    System.out.println("Reading Fetched Data...");
                    playerList = (players) o;
                    System.out.println("Setting Up Database...");
                } else if (o instanceof LoginDTO) {
                    LoginDTO loginDTO = (LoginDTO) o;
                    if (loginDTO.isStatus()) {
                        socketWrapper.write("login," + loginDTO.getClubName());
                    } else {
                        ShowError("Invalid Credentials");
                    }
                } else if (o instanceof List<?>) {
                    List<player> list = (List<player>) o;
                    String clubname = list.get(0).getClub();
                    Platform.runLater(() -> {
                        try {
                            System.out.println("Dashboard in login entered");
                            main.showDashboard(clubname, list); // Show the dashboard with fetched list
                        } catch (Exception e) {
                            e.printStackTrace();
                            System.out.println("Exception While Showing Dashboard in ReadThreadClient");
                        }
                    });
                } else if (o instanceof String) {
                    String msg = (String) o;
                    String[] tokens = msg.split(",");
                    if (tokens[0].equals("Error") && tokens[1].equals("Selling")) {
                        ShowError("This player can't be sold");
                    } else if (tokens[0].equals("Error") && tokens[1].equals("Buying")) {
                        ShowError("This player can't be bought");
                    } else if (tokens[0].equals("Success") && tokens[1].equals("Selling")) {
                        ShowOk("Selling Successful");
                    } else if (tokens[0].equals("Success") && tokens[1].equals("Buying")) {
                        ShowOk("Buying Successful");
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                System.out.println("Error While Sending Request To The Server");
            }
        }
    }
}
