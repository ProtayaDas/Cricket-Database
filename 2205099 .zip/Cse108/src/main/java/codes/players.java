package codes;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class players implements Serializable {
    public List<player> list = new ArrayList<>();

    public void addInList(player p) {
        list.add(p);
    }

    public boolean isDuplicate(player newPlayer) {
        for (player p : list) {
            if (p.getName().equalsIgnoreCase(newPlayer.getName()) &&
                    p.getCountry().equalsIgnoreCase(newPlayer.getCountry()) &&
                    p.getAge() == newPlayer.getAge() &&
                    p.getHeight() == newPlayer.getHeight() &&
                    p.getClub().equalsIgnoreCase(newPlayer.getClub()) &&
                    p.getPosition().equalsIgnoreCase(newPlayer.getPosition()) &&
                    p.getJerseyNumber() == newPlayer.getJerseyNumber() &&
                    p.getSalary() == newPlayer.getSalary()) {
                return true;
            }
        }
        return false;
    }

    public void load() {
        String filePath = "E:\\Cse108\\src\\main\\resources\\codes\\players.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] data = line.split(",");
                if (data.length < 8) continue;
                try {
                    String name = data[0];
                    String country = data[1];
                    int age = Integer.parseInt(data[2]);
                    double height = Double.parseDouble(data[3]);
                    String club = data[4];
                    String position = data[5];
                    int number = data[6].isEmpty() ? -1 : Integer.parseInt(data[6]);
                    int weeklySalary = Integer.parseInt(data[7]);
                    player p = new player(name, country, age, height, club, position, number, weeklySalary);
                    if (!isDuplicate(p)) {
                        this.addInList(p);
                    }
                } catch (NumberFormatException e) {
                    continue;
                }
            }
        } catch (IOException e) {
        }
    }

    public void add_to_file(player newPlayer) {
        if (isDuplicate(newPlayer)) {
            return;
        }
        String filePath = "E:\\Cse108\\src\\main\\resources\\codes\\players.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            String line = newPlayer.getName() + "," + newPlayer.getCountry() + "," + newPlayer.getAge() + "," +
                    newPlayer.getHeight() + "," + newPlayer.getClub() + "," + newPlayer.getPosition() + "," +
                    (newPlayer.getJerseyNumber() == -1 ? "" : newPlayer.getJerseyNumber()) + "," + newPlayer.getSalary();
            writer.newLine();
            writer.write(line);
            this.addInList(newPlayer);
        } catch (IOException e) {
        }
    }

    public List<player> searchName(String name) {
        name = name.toLowerCase();
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            if (name.equals(p.getName().toLowerCase())) {
                Player.add(p);
            }
        }
        return Player;
    }

    public int searchNameNumber(String name) {
        name = name.toLowerCase();
        for (player p : list) {
            if (name.equals(p.getName().toLowerCase())) {
                return 1;
            }
        }
        return 0;
    }

    public List<player> searchClubCountry(String country, String club) {
        country = country.toLowerCase();
        club = club.toLowerCase();
        List<player> Player = new ArrayList<>();
        if (club.equals("any")) {
            for (player p : list) {
                if (country.equals(p.getCountry().toLowerCase())) {
                    Player.add(p);
                }
            }
        } else {
            for (player p : list) {
                if (club.equals(p.getClub().toLowerCase()) && country.equals(p.getCountry().toLowerCase())) {
                    Player.add(p);
                }
            }
        }
        System.out.println("ami ekhane "+club+" "+country+" "+Player.size());
        return Player;
    }

    public List<player> searchNameCountry(String name, String country) {
        country = country.toLowerCase();
        name = name.toLowerCase();
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            if (country.equals(p.getCountry().toLowerCase()) && name.equals(p.getName().toLowerCase())) {
                Player.add(p);
            }
        }
        return Player;
    }

    public List<player> searchPosition(String position) {
        position = position.toLowerCase();
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            if (position.equals(p.getPosition().toLowerCase())) {
                Player.add(p);
            }
        }
        return Player;
    }

    public List<player> searchSalary(long low, long high) {
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            //System.out.println(p.getSalary());
            if (p.getSalary() >= low && p.getSalary() <= high) {
                Player.add(p);
            }
        }
        return Player;
    }
    public static boolean containsDigit(String input) {
        for (char c : input.toCharArray()) {
            if (Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }
    public HashMap<String, Integer> searchCountry() {
        HashMap<String, Integer> m = new HashMap<>();
        for (player p : list) {
            String country = p.getCountry();

            if (m.containsKey(country)) {
                m.put(country, m.get(country) + 1);
            } else {
                //System.out.println("ami ekhane "+country+" "+m.get(country));
                if(containsDigit(country))
                    m.put(country, 1);
            }
        }
        //m.forEach((key, value) -> System.out.println(key + ": " + value + "\n"));
        return m;
    }

    public List<player> searchMaximumSalaryClub(String club) {
        club = club.toLowerCase();
        List<player> playersWithMaxSalary = new ArrayList<>();
        int highestSalary = 0;
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase())) {
                if (p.getSalary() > highestSalary) {
                    highestSalary = p.getSalary();
                }
            }
        }
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase()) && p.getSalary() == highestSalary) {
                playersWithMaxSalary.add(p);
            }
        }
        return playersWithMaxSalary;
    }

    public List<player> searchMaximumAgeClub(String club) {
        club = club.toLowerCase();
        int highest = 0;
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase())) {
                highest = Math.max(highest, p.getAge());
            }
        }
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase()) && p.getAge() == highest) {
                Player.add(p);
            }
        }
        return Player;
    }

    public List<player> searchMaximumHeightClub(String club) {
        club = club.toLowerCase();
        double highest = 0;
        List<player> Player = new ArrayList<>();
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase())) {
                highest = Math.max(highest, p.getHeight());
            }
        }
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase())) {
                if (highest == p.getHeight())
                    Player.add(p);
            }
        }
        return Player;
    }

    public int searchSalaryClub(String club) {
        club = club.toLowerCase();
        int total = 0;
        int found = 0;
        for (player p : list) {
            if (club.equals(p.getClub().toLowerCase())) {
                total += p.getSalary();
                found++;
            }
        }
        if (found > 0) return total;
        return -1;
    }
}
